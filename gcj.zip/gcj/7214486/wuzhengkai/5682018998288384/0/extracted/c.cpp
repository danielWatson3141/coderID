#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <utility>
#define mp make_pair
#define LL long long
#define MOD 1000000007

using namespace std;


vector<pair<int,int> > g[10010];
vector<int> back[10010];
char s[10010];
int tt;
int n;
vector<int> tmp;

void gethash(int x,int rt,int idx) {
	if (g[rt][idx].second!=-1) return;
	for (int i=0;i<(int)g[x].size();++i)
		if (g[x][i].first!=rt) gethash(g[x][i].first,x,i);

	tmp.clear();
	for (int i=0;i<(int)g[x].size();++i)
		if (g[x][i].first!=rt) tmp.push_back(g[x][i].second);
	sort(tmp.begin(),tmp.end());
	LL now=s[x];
	for (int i=0;i<(int)tmp.size();++i)
		now=(now*123+tmp[i])%MOD;
	g[rt][idx].second=now;
}

map<int,int> can;

bool dfs(int x,int rt) {
	can.clear();
	for (int i=0;i<(int)g[x].size();++i)
		if (g[x][i].first!=rt)
			can[g[x][i].second]++;
	int cur=-1;
	for (map<int,int>::iterator it=can.begin();it!=can.end();++it)
		if (it->second&1) {
			if (cur==-1) cur=it->first;
			else return false;
		}
	if (cur==-1) return true;
	for (int i=0;i<(int)g[x].size();++i)
		if (g[x][i].first!=rt && g[x][i].second==cur)
			if (dfs(g[x][i].first,x)) return true;
	return false;
}

int main() {
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);

	scanf("%d",&tt);
	for (int ii=1;ii<=tt;++ii) {
		cin >> n;
		for (int i=0;i<n;++i) {
			g[i].clear();
			back[i].clear();
		}
		for (int i=0;i<n;++i)
			cin >> s[i];
		for (int i=0;i<n-1;++i) {
			int x,y;
			scanf("%d%d",&x,&y);
			x--,y--;
			g[x].push_back(mp(y,-1));
			g[y].push_back(mp(x,-1));
			back[x].push_back(g[y].size()-1);
			back[y].push_back(g[x].size()-1);
		}


		bool flag=false;
		for (int i=0;i<n;++i)
			for (int j=0;j<(int)g[i].size();++j)
				gethash(g[i][j].first,i,j);

		/*
		for (int i=0;i<n;++i) {
			printf("Node %d:\n",i);
			for (int j=0;j<(int)g[i].size();++j)
				printf("%d %d\n",g[i][j].first,g[i][j].second);
			printf("\n");
		}
		*/

		for (int i=0;i<n;++i)
			for (int j=0;j<(int)g[i].size();++j)
				if (g[i][j].second==g[g[i][j].first][back[i][j]].second) {
					flag=true;
					break;
				}


		for (int i=0;i<n;++i)
			if (dfs(i,-1)) {
				flag=true;
				break;
			}

		printf("Case #%d: ",ii);
		if (flag) printf("SYMMETRIC\n");
		else printf("NOT SYMMETRIC\n");
	}

}
