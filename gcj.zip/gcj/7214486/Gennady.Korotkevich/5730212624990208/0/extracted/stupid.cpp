#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

const int N = 1234;

char g[N][N];
int a[N];

int main() {
  freopen("in", "r", stdin);
  freopen("out", "w", stdout);
  int tt;
  scanf("%d", &tt);
  for (int qq = 1; qq <= tt; qq++) {
    printf("Case #%d:", qq);
    fflush(stdout);
    int n, fav;
    scanf("%d %d", &n, &fav);
    for (int i = 0; i < n; i++) {
      scanf("%s", g[i]);
    }
    for (int i = 0; i < n; i++) {
      a[i] = i;
    }
    bool ok = false;
    do {
      int res = a[0];
      for (int i = 1; i < n; i++) {
        if (g[res][a[i]] == 'N') {
          res = a[i];
        }
      }
      if (res == fav) {
        ok = true;
        break;
      }
    } while (next_permutation(a, a + n));
    if (!ok) {
      printf(" IMPOSSIBLE\n");
    } else {
      for (int i = 0; i < n; i++) {
        printf(" %d", a[i]);
      }
      printf("\n");
    }
    fflush(stdout);
  }
  return 0;
}
